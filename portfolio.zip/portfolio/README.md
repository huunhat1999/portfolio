# Modern Portfolio Website

A modern, responsive portfolio website built with React, TypeScript, and Material UI. This website features a clean design with smooth animations and showcases your skills and projects effectively.

## Features

- 🎨 Modern and clean design with Material UI components
- 📱 Fully responsive layout
- ✨ Smooth scroll animations
- 🎯 Skills showcase with progress bars
- 💼 Project portfolio with live demo and GitHub links
- 🎭 Themeable styling with Material UI's theme system
- 📝 TypeScript for better type safety

## Prerequisites

Before you begin, ensure you have the following installed:
- Node.js (v14 or higher)
- Yarn (v1.22 or higher)

## Getting Started

1. Clone the repository:
```bash
git clone <repository-url>
cd portfolio
```

2. Install dependencies:
```bash
yarn
```

3. Start the development server:
```bash
yarn start
```

4. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Project Structure

```
src/
├── components/         # React components
│   ├── Hero/          # Hero section component
│   ├── Skills/        # Skills section component
│   └── Portfolio/     # Portfolio section component
├── styles/            # Theme configuration
│   └── theme.tsx      # Material UI theme setup
├── types/             # TypeScript type definitions
├── hooks/             # Custom React hooks
└── App.tsx            # Main application component
```

## Customization

1. Update the theme colors in `src/styles/theme.tsx`
2. Modify the skills list in `src/components/Skills/Skills.tsx`
3. Update the projects list in `src/components/Portfolio/Portfolio.tsx`
4. Replace the profile image and project images in the `public` directory

## Built With

- [React](https://reactjs.org/) - A JavaScript library for building user interfaces
- [TypeScript](https://www.typescriptlang.org/) - Typed JavaScript at Any Scale
- [Material UI](https://mui.com/) - A comprehensive React UI component library
- [Framer Motion](https://www.framer.com/motion/) - A production-ready motion library for React

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details
