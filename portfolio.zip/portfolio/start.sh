#!/bin/bash

# Check if yarn is installed
if ! command -v yarn &> /dev/null
then
    echo "Yarn is not installed. Installing yarn..."
    npm install -g yarn
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    yarn install
fi

# Start the development server
echo "Starting development server..."
yarn start 