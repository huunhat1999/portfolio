import React from 'react';
import { RouteObject, Navigate } from 'react-router-dom';
import { Layout } from '../components/Layout/Layout';
import { HomePage, SkillsPage, PortfolioPage } from '../pages';
import { AboutPage } from '../pages/AboutPage';
import { ContactPage } from '../pages/ContactPage';

/**
 * Application routes configuration
 */
export const routes: RouteObject[] = [
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: 'about',
        element: <AboutPage />,
      },
      {
        path: 'skills',
        element: <SkillsPage />,
      },
      {
        path: 'portfolio',
        element: <PortfolioPage />,
      },
      {
        path: 'contact',
        element: <ContactPage />,
      },
      {
        path: '*',
        element: <Navigate to="/" replace />,
      },
    ],
  },
]; 