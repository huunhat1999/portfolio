import { Project } from "../types";

export const projects: Project[] = [
    {
      id: 1,
      title: 'Design Team',
      description: 'A collaborative platform for design teams to work together efficiently.',
      image: '/projects/anh1.jpg',
      technologies: ['React', 'TypeScript', 'Styled Components'],
      link: 'https://example.com/design-team',
      github: 'https://github.com/example/design-team',
      role: 'Full Stack Developer',
      duration: '6 months',
      teamSize: 'Team of 4',
      longDescription: 'This platform was developed to address the challenges faced by remote design teams. It offers real-time collaboration features, asset management, version control, and integrated communication tools to streamline the design process across distributed teams.',
      keyFeatures: [
        'Real-time collaborative design editing',
        'Design system management and version control',
        'Asset library with tagging and organization features',
        'Comment and feedback system integrated with designs',
        'Team activity dashboard and analytics'
      ],
      challenges: [
        'Creating a seamless real-time collaboration experience',
        'Implementing version control for complex design files',
        'Building a responsive interface that works across various devices',
        'Managing state across multiple concurrent users'
      ],
      solutions: [
        'Implemented WebSocket technology for real-time updates',
        'Created a custom version control system using Git principles',
        'Developed a responsive UI with breakpoints for all screen sizes',
        'Used Redux for predictable state management with optimistic updates'
      ]
    },
    {
      id: 2,
      title: 'Work From Home',
      description: 'Remote work management platform with integrated tools and analytics.',
      image: '/projects/anh2.jpg',
      technologies: ['Next.js', 'Node.js', 'MongoDB'],
      link: 'https://example.com/work-from-home',
      github: 'https://github.com/example/work-from-home',
      role: 'Backend Developer & DevOps',
      duration: '8 months',
      teamSize: 'Team of 6',
      longDescription: 'This comprehensive platform helps companies manage remote teams effectively. It includes time tracking, project management, communication tools, and analytics dashboards to provide insights into team productivity and collaboration patterns.',
      keyFeatures: [
        'Time tracking with activity monitoring',
        'Project management with task assignment and progress tracking',
        'Team chat and video conferencing integration',
        'Performance analytics and productivity reports',
        'Automated daily standup and report generation'
      ],
      challenges: [
        'Ensuring data privacy while providing necessary monitoring tools',
        'Creating a scalable architecture to handle thousands of concurrent users',
        'Developing meaningful analytics without invasive tracking',
        'Implementing secure authentication across multiple services'
      ],
      solutions: [
        'Designed privacy-first architecture with transparent user controls',
        'Implemented microservices architecture with containerization',
        'Created aggregated analytics to protect individual privacy',
        'Developed JWT-based authentication with SSO integration'
      ]
    },
    {
      id: 3,
      title: 'Work From Home',
      description: 'Remote work management platform with integrated tools and analytics.',
      image: '/projects/anh3.jpg',
      technologies: ['React', 'TypeScript', 'Styled Components'],
      link: 'https://example.com/design-team',
      github: 'https://github.com/example/design-team',
      role: 'Frontend Lead',
      duration: '10 months',
      teamSize: 'Team of 5',
      longDescription: 'This e-learning platform provides interactive courses for professionals looking to develop new skills. It features video lessons, interactive exercises, progress tracking, and certification upon course completion. The platform uses adaptive learning to personalize content for each user.',
      keyFeatures: [
        'Interactive video lessons with quizzes and exercises',
        'Personalized learning paths using AI recommendations',
        'Progress tracking and skill assessment',
        'Certificate generation upon course completion',
        'Discussion forums and mentor connections'
      ],
      challenges: [
        'Creating engaging interactive content for technical subjects',
        'Designing a UI that works well for various learning styles',
        'Implementing an effective recommendation system',
        'Ensuring accessibility for all users'
      ],
      solutions: [
        'Developed interactive coding environments embedded in lessons',
        'Designed a flexible UI with customizable learning views',
        'Implemented a hybrid recommendation system using user preferences and performance',
        'Built the platform following WCAG 2.1 AA guidelines'
      ]
    },
    {
      id: 4,
      title: 'Work From Home',
      description: 'Remote work management platform with integrated tools and analytics.',
      image: '/projects/anh4.jpg',
      technologies: ['React', 'TypeScript', 'Styled Components'],
      role: 'Mobile Developer',
      duration: '7 months',
      teamSize: 'Team of 3',
      longDescription: 'This healthcare application connects patients with medical professionals for remote monitoring and care. It integrates with wearable devices to track vital signs, medication adherence, and patient activity, providing real-time data to healthcare providers.',
      keyFeatures: [
        'Real-time health metrics monitoring from connected devices',
        'Medication tracking and reminders',
        'Secure messaging between patients and healthcare providers',
        'Appointment scheduling and video consultations',
        'Emergency alert system with location services'
      ],
      challenges: [
        'Ensuring data privacy and HIPAA compliance',
        'Creating reliable connections with various health devices',
        'Building an intuitive interface for elderly users',
        'Managing battery consumption while maintaining real-time monitoring'
      ],
      solutions: [
        'Implemented end-to-end encryption and secure storage',
        'Built a flexible device integration layer with fallback mechanisms',
        'Conducted extensive user testing with target demographics',
        'Optimized background processes and implemented intelligent polling'
      ]
    },
    {
      id: 5,
      title: 'Work From Home',
      description: 'Remote work management platform with integrated tools and analytics.',
      image: '/projects/anh5.jpg',
      technologies: ['React', 'TypeScript', 'Styled Components'],
      role: 'Full Stack Developer',
      duration: '9 months',
      teamSize: 'Solo project',
      longDescription: 'This financial platform helps users manage their personal finances, track investments, and plan for future financial goals. It includes budgeting tools, investment portfolio analysis, retirement planning calculators, and educational resources on financial literacy.',
      keyFeatures: [
        'Bank account and credit card synchronization',
        'Automated expense categorization and budget tracking',
        'Investment portfolio management and performance analysis',
        'Financial goal setting and progress monitoring',
        'Tax optimization recommendations'
      ],
      challenges: [
        'Securing sensitive financial data',
        'Integrating with multiple financial institutions',
        'Providing accurate investment performance calculations',
        'Designing intuitive visualizations for complex financial data'
      ],
      solutions: [
        'Implemented bank-level security measures and encryption',
        'Used Plaid API for secure financial institution connections',
        'Developed a robust calculation engine for financial metrics',
        'Created customizable dashboard with interactive visualizations'
      ]
    },
    {
      id: 6,
      title: 'Work From Home',
      description: 'Remote work management platform with integrated tools and analytics.',
      image: '/projects/anh6.jpg',
      technologies: ['React', 'TypeScript', 'Styled Components'],
      role: 'Full Stack Developer',
      duration: '11 months',
      teamSize: 'Team of 2',
      longDescription: 'This e-commerce platform provides small businesses with enterprise-level tools to sell products online. It includes inventory management, payment processing, shipping integration, customer relationship management, and marketing tools in a unified dashboard.',
      keyFeatures: [
        'Product catalog management with variant support',
        'Multi-payment gateway integration',
        'Automated shipping and fulfillment',
        'Customer segmentation and personalized marketing',
        'Sales analytics and inventory forecasting'
      ],
      challenges: [
        'Building a scalable system for high-traffic periods',
        'Creating a smooth checkout experience across devices',
        'Implementing reliable inventory management',
        'Optimizing site performance for conversion'
      ],
      solutions: [
        'Designed a scalable architecture with caching and load balancing',
        'Built a streamlined multi-step checkout with persistence',
        'Implemented real-time inventory tracking with webhooks',
        'Optimized frontend performance with code splitting and lazy loading'
      ]
    },
  ];