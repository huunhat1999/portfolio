export const theme = {
  colors: {
    primary: '#4361ee',    // Vibrant blue
    secondary: '#3f37c9',  // Deep blue-purple
    accent: '#4cc9f0',     // Bright cyan
    success: '#4ade80',    // Vibrant green
    warning: '#fbbf24',    // Warm amber
    error: '#f87171',      // Soft red
    background: '#f8fafc', // Light background
    paper: '#ffffff',      // White
    text: '#1e293b',       // Dark slate
    textLight: '#64748b',  // Slate gray
    gradient: 'linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%)',
  },
  fonts: {
    body: "'Inter', sans-serif",
    heading: "'Poppins', sans-serif",
  },
  breakpoints: {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
  },
  spacing: {
    xs: '0.25rem',
    sm: '0.5rem',
    md: '1rem',
    lg: '1.5rem',
    xl: '2rem',
    xxl: '3rem',
  },
  borderRadius: {
    sm: '0.25rem',
    md: '0.5rem',
    lg: '1rem',
    full: '9999px',
  },
  shadows: {
    small: '0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.05)',
    medium: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    large: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
  }
} as const;

export type Theme = typeof theme; 