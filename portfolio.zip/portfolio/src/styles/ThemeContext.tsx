import React, { createContext, useContext, useState, useMemo } from 'react';
import { ThemeProvider as MuiThemeProvider, createTheme } from '@mui/material/styles';
import { PaletteMode } from '@mui/material';
import { theme as baseTheme } from './theme';

type ThemeContextType = {
  mode: PaletteMode;
  toggleColorMode: () => void;
};

export const ThemeContext = createContext<ThemeContextType>({
  mode: 'light',
  toggleColorMode: () => {},
});

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setMode] = useState<PaletteMode>('light');

  const colorMode = useMemo(
    () => ({
      mode,
      toggleColorMode: () => {
        setMode((prevMode) => (prevMode === 'light' ? 'dark' : 'light'));
      },
    }),
    [mode]
  );

  const theme = useMemo(() => {
    return createTheme({
      palette: {
        mode,
        primary: {
          main: baseTheme.colors.primary,
          light: mode === 'light' ? '#6387ff' : '#2c4ddb',
          dark: mode === 'light' ? '#2c4ddb' : '#6387ff',
        },
        secondary: {
          main: baseTheme.colors.secondary,
          light: mode === 'light' ? '#5e4de6' : '#2f2b97',
          dark: mode === 'light' ? '#2f2b97' : '#5e4de6',
        },
        error: {
          main: baseTheme.colors.error,
        },
        warning: {
          main: baseTheme.colors.warning,
        },
        success: {
          main: baseTheme.colors.success,
        },
        info: {
          main: baseTheme.colors.accent,
        },
        background: {
          default: mode === 'light' ? baseTheme.colors.background : '#0f172a',
          paper: mode === 'light' ? baseTheme.colors.paper : '#1e293b',
        },
        text: {
          primary: mode === 'light' ? baseTheme.colors.text : '#f1f5f9',
          secondary: mode === 'light' ? baseTheme.colors.textLight : '#cbd5e1',
        },
      },
      typography: {
        fontFamily: baseTheme.fonts.body,
        h1: {
          fontFamily: baseTheme.fonts.heading,
          fontWeight: 700,
        },
        h2: {
          fontFamily: baseTheme.fonts.heading,
          fontWeight: 700,
        },
        h3: {
          fontFamily: baseTheme.fonts.heading,
          fontWeight: 600,
        },
        h4: {
          fontFamily: baseTheme.fonts.heading,
          fontWeight: 600,
        },
        h5: {
          fontFamily: baseTheme.fonts.heading,
          fontWeight: 500,
        },
        h6: {
          fontFamily: baseTheme.fonts.heading,
          fontWeight: 500,
        },
        button: {
          fontWeight: 500,
          textTransform: 'none',
        },
      },
      shape: {
        borderRadius: parseInt(baseTheme.borderRadius.md.replace('rem', '')) * 16,
      },
      components: {
        MuiButton: {
          styleOverrides: {
            root: {
              borderRadius: '8px',
              boxShadow: mode === 'light' ? baseTheme.shadows.small : 'none',
            },
            contained: {
              background: mode === 'light' ? baseTheme.colors.gradient : baseTheme.colors.primary,
              '&:hover': {
                boxShadow: baseTheme.shadows.medium,
                transform: 'translateY(-2px)',
              },
            },
          },
        },
        MuiCard: {
          styleOverrides: {
            root: {
              boxShadow: mode === 'light' ? baseTheme.shadows.medium : baseTheme.shadows.small,
              transition: 'all 0.3s ease',
            },
          },
        },
      },
    });
  }, [mode]);

  return (
    <ThemeContext.Provider value={colorMode}>
      <MuiThemeProvider theme={theme}>{children}</MuiThemeProvider>
    </ThemeContext.Provider>
  );
};

export const useThemeContext = () => useContext(ThemeContext); 