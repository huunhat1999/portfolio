import { Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';

interface TypingLoopTextProps {
  text: any;
  speed?: number;      // Tốc độ gõ
  deleteSpeed?: number; // Tốc độ xóa
  delay?: number;      // Thời gian giữ chữ trước khi xóa
}

const TypingLoopText: React.FC<TypingLoopTextProps> = ({
  text,
  speed = 100,
  deleteSpeed = 70,
  delay = 1500,
}) => {
  const [displayedText, setDisplayedText] = useState('');
  const [index, setIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    let timeout: NodeJS.Timeout;

    if (!isDeleting && index < text.length) {
      timeout = setTimeout(() => {
        setDisplayedText((prev) => prev + text[index]);
        setIndex((prev) => prev + 1);
      }, speed);
    } else if (!isDeleting && index === text.length) {
      // Giữ nguyên nội dung 1 lúc trước khi xóa
      timeout = setTimeout(() => {
        setIsDeleting(true);
      }, delay);
    } else if (isDeleting && index > 0) {
      timeout = setTimeout(() => {
        setDisplayedText((prev) => prev.slice(0, -1));
        setIndex((prev) => prev - 1);
      }, deleteSpeed);
    } else if (isDeleting && index === 0) {
      setIsDeleting(false);
    }

    return () => clearTimeout(timeout);
  }, [index, isDeleting, text, speed, deleteSpeed, delay]);

  return (
    <Typography variant="h1" component="h1" sx={{ fontSize: '2.5rem', fontWeight: 600, lineHeight: 1.2 }}>
      {displayedText}
      <span className="animate-pulse">.</span>
    </Typography>
  );
};

export default TypingLoopText;
