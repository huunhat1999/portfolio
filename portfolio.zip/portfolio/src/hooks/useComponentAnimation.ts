import { useInView } from 'framer-motion';
import { useRef } from 'react';

interface AnimationOptions {
  direction?: 'up' | 'down' | 'left' | 'right';
  distance?: number;
  delay?: number;
  duration?: number;
  once?: boolean;
}

export const useComponentAnimation = (options: AnimationOptions = {}) => {
  const {
    direction = 'up',
    distance = 50,
    delay = 0.2,
    duration = 0.7,
    once = true
  } = options;

  const ref = useRef(null);
  const isInView = useInView(ref, { once, margin: "-100px" });

  // Determine transform based on direction
  let transform = '';
  switch (direction) {
    case 'up':
      transform = `translateY(${distance}px)`;
      break;
    case 'down':
      transform = `translateY(-${distance}px)`;
      break;
    case 'left':
      transform = `translateX(${distance}px)`;
      break;
    case 'right':
      transform = `translateX(-${distance}px)`;
      break;
    default:
      transform = `translateY(${distance}px)`;
  }

  return {
    ref,
    style: {
      transform: isInView ? "none" : transform,
      opacity: isInView ? 1 : 0,
      transition: `all ${duration}s cubic-bezier(0.17, 0.55, 0.55, 1) ${delay}s`
    }
  };
}; 