import React, { useState, useEffect } from 'react';
import { Box, Container, Typography, Paper, Grid, useTheme } from '@mui/material';
import { motion, useAnimation } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import PeopleIcon from '@mui/icons-material/People';
import CodeIcon from '@mui/icons-material/Code';
import AccessTimeIcon from '@mui/icons-material/AccessTime';

const statistics = [
  {
    label: 'Projects Completed',
    value: 50,
    icon: <TaskAltIcon sx={{ fontSize: 40 }} />,
  },
  {
    label: 'Happy Clients',
    value: 30,
    icon: <PeopleIcon sx={{ fontSize: 40 }} />,
  },
  {
    label: 'Code Lines Written',
    value: 200000,
    formatter: (value: number) => `${Math.floor(value / 1000)}k+`,
    icon: <CodeIcon sx={{ fontSize: 40 }} />,
  },
  {
    label: 'Hours of Work',
    value: 5000,
    formatter: (value: number) => `${Math.floor(value / 1000)}k+`,
    icon: <AccessTimeIcon sx={{ fontSize: 40 }} />,
  },
];

const CountUp = ({ end, duration = 2, formatter = (n: number) => n.toString() }: { end: number; duration?: number; formatter?: (n: number) => string }) => {
  const [count, setCount] = useState(0);
  const [ref, inView] = useInView({ triggerOnce: true });
  const controls = useAnimation();

  useEffect(() => {
    if (inView) {
      controls.start({ opacity: 1, y: 0 });
      let startTimestamp: number;
      const step = (timestamp: number) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / (duration * 1000), 1);
        setCount(Math.floor(progress * end));
        if (progress < 1) {
          window.requestAnimationFrame(step);
        }
      };
      window.requestAnimationFrame(step);
    }
  }, [inView, end, duration, controls]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={controls}
      transition={{ duration: 0.5 }}
    >
      <Typography variant="h3" component="p" fontWeight={700}>
        {formatter(count)}
      </Typography>
    </motion.div>
  );
};

export const Statistics: React.FC = () => {
  const theme = useTheme();

  return (
    <Box
      component="section"
      id="statistics"
      sx={{
        py: 10,
        backgroundColor: theme.palette.mode === 'light'
          ? 'linear-gradient(135deg, rgba(67, 97, 238, 0.08) 0%, rgba(76, 201, 240, 0.12) 100%)'
          : 'linear-gradient(135deg, rgba(67, 97, 238, 0.15) 0%, rgba(30, 41, 59, 1) 100%)',
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4} justifyContent="center">
          {statistics.map((stat, index) => (
            <Grid item xs={6} md={3} key={index}>
              <Paper
                elevation={0}
                sx={{
                  p: 3,
                  textAlign: 'center',
                  height: '100%',
                  borderRadius: '16px',
                  backgroundColor: theme.palette.mode === 'light'
                    ? 'rgba(255, 255, 255, 0.9)'
                    : 'rgba(30, 41, 59, 0.5)',
                  backdropFilter: 'blur(8px)',
                  border: `1px solid ${theme.palette.mode === 'light' 
                    ? 'rgba(255, 255, 255, 0.8)' 
                    : 'rgba(255, 255, 255, 0.1)'}`,
                  boxShadow: theme.palette.mode === 'light'
                    ? '0 10px 30px rgba(67, 97, 238, 0.1)'
                    : '0 10px 30px rgba(0, 0, 0, 0.2)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: 70,
                    height: 70,
                    borderRadius: '50%',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    color: theme.palette.primary.main,
                    mb: 2
                  }}
                >
                  {stat.icon}
                </Box>
                <CountUp 
                  end={stat.value} 
                  formatter={stat.formatter || ((n: number) => n.toString())} 
                />
                <Typography 
                  variant="subtitle1" 
                  color="text.secondary" 
                  sx={{ mt: 1 }}
                >
                  {stat.label}
                </Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
}; 