import React from 'react';
import { Box, Container, Typography, Card, CardContent, LinearProgress, useTheme } from '@mui/material';
import { motion } from 'framer-motion';
import { useComponentAnimation } from '../../hooks/useComponentAnimation';
import { Skill } from '../../types';
import { PageHeader } from '../PageHeader/PageHeader';

const skills: Skill[] = [
  { name: 'Web Design', icon: '/icons/web-design.svg', level: 40 },
  { name: 'HTML/CSS', icon: '/icons/html-css.svg', level: 95 },
  { name: 'JavaScript', icon: '/icons/javascript.svg', level:75 },
  { name: 'React', icon: '/icons/react.svg', level: 90 },
  { name: 'Mobile Development', icon: '/icons/mobile-development.svg', level: 40 },
  { name: 'UI/UX Design', icon: '/icons/ui-ux-design.svg', level: 20 },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { y: 20, opacity: 0 },
  show: { 
    y: 0, 
    opacity: 1,
    transition: {
      duration: 0.5,
      ease: "easeOut"
    }
  }
};

// Animation for the progress bar
const progressVariants = {
  initial: { width: 0 },
  animate: (level: number) => ({
    width: `${level}%`,
    transition: { 
      duration: 1.2,
      ease: "easeOut",
      delay: 0.3
    }
  })
};

export const Skills: React.FC = () => {
  const theme = useTheme();
  const titleAnimation = useComponentAnimation();
  const MotionCard = motion(Card);

  return (
    <Box
      id="skills"
      component="section"
      sx={{
        py: 12,
        backgroundColor: theme.palette.mode === 'light' 
          ? 'rgba(248, 250, 252, 0.8)'
          : theme.palette.background.paper,
        position: 'relative',
        '&::before': theme.palette.mode === 'light' ? {
          content: '""',
          position: 'absolute',
          top: 0,
          right: 0,
          width: '100%',
          height: '100%',
          backgroundImage: 'radial-gradient(circle at 70% 60%, rgba(76, 201, 240, 0.1) 0%, rgba(248, 250, 252, 0) 50%)',
          zIndex: 0,
        } : {},
      }}
    >
      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Box ref={titleAnimation.ref} style={titleAnimation.style}>
          <PageHeader 
            title="MY SKILLS" 
            subtitle="Here are the technologies and skills I've developed through my journey as a web developer"
          />
        </Box>
        
        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          <Box sx={{ display: 'flex', flexWrap: 'wrap', margin: -2 }}>
            {skills.map((skill) => (
              <Box 
                key={skill.name} 
                sx={{ 
                  width: { xs: '100%', sm: '50%', md: '33.3%' },
                  padding: 2,
                }}
              >
                <motion.div variants={item}>
                  <MotionCard
                    sx={{ 
                      height: '100%',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      position: 'relative',
                      transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease',
                      '&:hover': {
                        transform: 'translateY(-8px)',
                        boxShadow: theme.palette.mode === 'light' 
                          ? '0 15px 30px rgba(67, 97, 238, 0.1)' 
                          : '0 15px 30px rgba(0, 0, 0, 0.2)',
                      },
                      '&::before': theme.palette.mode === 'light' ? {
                        content: '""',
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '4px',
                        background: skill.level > 80 
                          ? 'linear-gradient(90deg, #4361ee, #4cc9f0)'
                          : skill.level > 60
                            ? 'linear-gradient(90deg, #4361ee, #fbbf24)'
                            : 'linear-gradient(90deg, #4cc9f0, #f87171)',
                      } : {},
                    }}
                  >
                    <CardContent sx={{ p: 3 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                        <Box
                          sx={{
                            width: 50,
                            height: 50,
                            borderRadius: '12px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            backgroundColor: theme.palette.mode === 'light' 
                              ? 'rgba(67, 97, 238, 0.1)'
                              : 'rgba(67, 97, 238, 0.2)',
                            marginRight: 2
                          }}
                        >
                          <Box
                            component="img"
                            src={skill.icon}
                            alt={skill.name}
                            sx={{
                              width: 30,
                              height: 30
                            }}
                          />
                        </Box>
                        <Box>
                          <Typography
                            variant="h6"
                            component="h3"
                            sx={{
                              color: theme.palette.primary.main,
                              fontWeight: 600,
                              mb: 0.5
                            }}
                          >
                            {skill.name}
                          </Typography>
                          <Typography
                            variant="body2"
                            sx={{
                              color: theme.palette.text.secondary,
                              fontSize: '0.875rem'
                            }}
                          >
                            {skill.level}% proficiency
                          </Typography>
                        </Box>
                      </Box>
                      <Box sx={{ position: 'relative', height: 10, mb: 1, borderRadius: 5, backgroundColor: theme.palette.mode === 'light' ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)' }}>
                        <motion.div
                          initial="initial"
                          whileInView="animate"
                          viewport={{ once: true }}
                          custom={skill.level}
                          variants={progressVariants}
                          style={{
                            position: 'absolute',
                            height: '100%',
                            borderRadius: 5,
                            background: theme.palette.mode === 'light'
                              ? skill.level > 80 
                                ? 'linear-gradient(90deg, #4361ee, #4cc9f0)'
                                : skill.level > 60
                                  ? 'linear-gradient(90deg, #4361ee, #fbbf24)'
                                  : 'linear-gradient(90deg, #4cc9f0, #f87171)'
                              : skill.level > 80 
                                ? 'linear-gradient(90deg, #4361ee, #4cc9f0)'
                                : skill.level > 60
                                  ? 'linear-gradient(90deg, #4361ee, #fbbf24)'
                                  : 'linear-gradient(90deg, #4cc9f0, #f87171)'
                          }}
                        />
                      </Box>
                    </CardContent>
                  </MotionCard>
                </motion.div>
              </Box>
            ))}
          </Box>
        </motion.div>
      </Container>
    </Box>
  );
}; 