import React from 'react';
import { Box, Typography, useTheme } from '@mui/material';
import { useComponentAnimation } from '../../hooks/useComponentAnimation';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
}

export const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle }) => {
  const theme = useTheme();
  const animation = useComponentAnimation();

  return (
    <Box 
      ref={animation.ref} 
      style={animation.style} 
      sx={{ 
        mb: 8, 
        textAlign: 'center',
        position: 'relative'
      }}
    >
      <Typography
        variant="h2"
        component="h1"
        gutterBottom
        sx={{
          fontSize: { xs: '2rem', md: '2.5rem' },
          fontWeight: 700,
          color: theme.palette.primary.main,
          mb: subtitle ? 1 : 0,
          position: 'relative',
          display: 'inline-block',
          '&::after': {
            content: '""',
            position: 'absolute',
            bottom: -8,
            left: '50%',
            transform: 'translateX(-50%)',
            width: '80px',
            height: '4px',
            background: theme.palette.mode === 'light' 
              ? 'linear-gradient(90deg, #4361ee, #4cc9f0)'
              : 'linear-gradient(90deg, #6387ff, #4cc9f0)',
            borderRadius: '2px',
          }
        }}
      >
        {title}
      </Typography>
      
      {subtitle && (
        <Typography
          variant="body1"
          sx={{
            fontSize: '1.1rem',
            color: theme.palette.text.secondary,
            maxWidth: '700px',
            margin: '1.5rem auto 0',
          }}
        >
          {subtitle}
        </Typography>
      )}
    </Box>
  );
}; 