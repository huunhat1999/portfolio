import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Fab, Zoom, useScrollTrigger, useTheme } from '@mui/material';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';

export const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();
  const theme = useTheme();
  const [showButton, setShowButton] = useState(false);
  
  // Scroll to top automatically when navigating
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  
  // Show/hide scroll button based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowButton(true);
      } else {
        setShowButton(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
  
  return (
    <Zoom in={showButton}>
      <Fab
        color="primary"
        size="small"
        aria-label="scroll back to top"
        onClick={handleScrollToTop}
        sx={{
          position: 'fixed',
          bottom: 24,
          right: 24,
          zIndex: 1000,
          background: theme.palette.mode === 'light' 
            ? 'linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%)' 
            : 'linear-gradient(135deg, #3f37c9 0%, #4361ee 100%)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
          '&:hover': {
            background: theme.palette.mode === 'light' 
              ? 'linear-gradient(135deg, #3050db 0%, #35b4db 100%)' 
              : 'linear-gradient(135deg, #332da8 0%, #3651d1 100%)',
            transform: 'translateY(-2px)',
            boxShadow: '0 6px 16px rgba(0, 0, 0, 0.2)',
          },
          transition: 'all 0.3s ease',
        }}
      >
        <KeyboardArrowUpIcon />
      </Fab>
    </Zoom>
  );
};

export default ScrollToTop; 