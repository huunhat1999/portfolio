import React from 'react';
import { Box, Container, Typography, Button, useTheme } from '@mui/material';
import { motion } from 'framer-motion';
import { useComponentAnimation } from '../../hooks/useComponentAnimation';
import { Link as RouterLink } from 'react-router-dom';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';

export const CTA: React.FC = () => {
  const theme = useTheme();
  const animation = useComponentAnimation();

  return (
    <Box
      component="section"
      sx={{
        py: 12,
        backgroundColor: theme.palette.mode === 'light'
          ? 'linear-gradient(135deg, rgba(67, 97, 238, 0.07) 0%, rgba(76, 201, 240, 0.1) 100%)'
          : 'linear-gradient(135deg, rgba(15, 23, 42, 1) 0%, rgba(30, 41, 59, 0.95) 100%)',
        position: 'relative',
        overflow: 'hidden',
        '&::before': theme.palette.mode === 'light' ? {
          content: '""',
          position: 'absolute',
          top: '-50%',
          right: '-10%',
          width: '600px',
          height: '600px',
          borderRadius: '50%',
          backgroundColor: 'rgba(67, 97, 238, 0.05)',
          zIndex: 0,
        } : {},
        '&::after': theme.palette.mode === 'light' ? {
          content: '""',
          position: 'absolute',
          bottom: '-50%',
          left: '-10%',
          width: '600px',
          height: '600px',
          borderRadius: '50%',
          backgroundColor: 'rgba(76, 201, 240, 0.05)',
          zIndex: 0,
        } : {},
      }}
    >
      <Container maxWidth="md" sx={{ position: 'relative', zIndex: 1 }}>
        <Box
          ref={animation.ref}
          style={animation.style}
          sx={{
            textAlign: 'center',
            p: { xs: 4, md: 6 },
            borderRadius: '24px',
            backgroundColor: theme.palette.mode === 'light'
              ? 'rgba(255, 255, 255, 0.9)'
              : 'rgba(30, 41, 59, 0.6)',
            backdropFilter: 'blur(10px)',
            boxShadow: theme.palette.mode === 'light'
              ? '0 20px 40px rgba(67, 97, 238, 0.1)'
              : '0 20px 40px rgba(0, 0, 0, 0.2)',
            border: `1px solid ${theme.palette.mode === 'light' 
              ? 'rgba(255, 255, 255, 0.8)' 
              : 'rgba(255, 255, 255, 0.1)'}`,
          }}
        >
          <Typography
            variant="h2"
            gutterBottom
            sx={{
              fontSize: { xs: '1.75rem', md: '2.5rem' },
              fontWeight: 700,
              background: theme.palette.mode === 'light' 
                ? 'linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%)' 
                : 'linear-gradient(135deg, #6387ff 30%, #4cc9f0 90%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              mb: 2,
            }}
          >
            Ready to Start Your Next Project?
          </Typography>
          
          <Typography
            variant="body1"
            sx={{
              fontSize: '1.1rem',
              color: theme.palette.text.secondary,
              maxWidth: '700px',
              margin: '0 auto 3rem',
              lineHeight: 1.6,
            }}
          >
            Let's collaborate to create something amazing. I'm currently available for
            freelance projects, full-time positions, or consulting work.
          </Typography>
          
          <motion.div
            whileHover={{ scale: 1.05 }}
            transition={{ type: 'spring', stiffness: 400, damping: 10 }}
          >
            <Button
              component={RouterLink}
              to="/contact"
              variant="contained"
              color="primary"
              size="large"
              endIcon={<ArrowForwardIcon />}
              sx={{
                py: 1.5,
                px: 4,
                borderRadius: '50px',
                fontWeight: 600,
                background: theme.palette.mode === 'light' 
                  ? 'linear-gradient(90deg, #4361ee, #4cc9f0)' 
                  : 'linear-gradient(90deg, #3f37c9, #4361ee)',
                boxShadow: '0 10px 20px rgba(67, 97, 238, 0.3)',
                '&:hover': {
                  boxShadow: '0 15px 30px rgba(67, 97, 238, 0.4)',
                  background: theme.palette.mode === 'light' 
                    ? 'linear-gradient(90deg, #3050db, #35b4db)' 
                    : 'linear-gradient(90deg, #332da8, #3651d1)',
                },
              }}
            >
              Get in Touch
            </Button>
          </motion.div>
        </Box>
      </Container>
    </Box>
  );
}; 