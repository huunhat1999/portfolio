import React from 'react';
import { Box, Container, Typography, Button, Stack, useTheme } from '@mui/material';
import { motion } from 'framer-motion';
import { useScrollAnimation } from '../../hooks/useScrollAnimation';
import TypingLoopText from '../../hooks/TypingLoopText';

export const Hero: React.FC = () => {
  const animation = useScrollAnimation();
  const MotionBox = motion(Box);
  const theme = useTheme();

  return (
    <Box 
      component="section"
      sx={{
        display: 'flex',
        alignItems: 'center',
        py: 12,
        position: 'relative',
        background: theme.palette.mode === 'light' 
          ? 'linear-gradient(135deg, rgba(67, 97, 238, 0.05) 0%, rgba(76, 201, 240, 0.1) 100%)' 
          : 'linear-gradient(135deg, rgba(15, 23, 42, 1) 0%, rgba(30, 41, 59, 1) 100%)',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundImage: 'radial-gradient(circle at 30% 20%, rgba(76, 201, 240, 0.15) 0%, rgba(67, 97, 238, 0) 25%)',
          zIndex: 0,
        },
      }}
    >
      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Stack 
          direction={{ xs: 'column-reverse', md: 'row' }} 
          spacing={6} 
          alignItems="center"
          justifyContent="space-between"
        >
          <Box sx={{ width: { xs: '100%', md: '50%' }, maxWidth: 600 }}>
            
            <Typography 
              variant="h1" 
              component="h1" 
              gutterBottom
              sx={{ 
                fontSize: { xs: '2.5rem', md: '3.5rem' },
                fontWeight: 700,
                lineHeight: 1.2,
                background: theme.palette.mode === 'light' 
                  ? 'linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%)' 
                  : 'linear-gradient(135deg, #6387ff 30%, #4cc9f0 90%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                mb: 2,
              }}
            >
              <TypingLoopText text="Hi, I'm Trần Hữu Nhật" />
           
            </Typography>
            <Typography 
              variant="body1" 
              paragraph
              sx={{ 
                fontSize: '1.2rem',
                mb: 4,
                color: theme.palette.text.secondary,
                lineHeight: 1.6,
              }}
            >
              I'm a passionate web developer with a love for creating beautiful and functional web experiences.
              I love creating innovative solutions and delivering high-quality products.
            </Typography>
            <Button 
              variant="contained" 
              color="primary"
              size="large"
              onClick={() => document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' })}
              sx={{ 
                px: 4, 
                py: 1.5,
                borderRadius: '10px',
                fontSize: '1rem',
                fontWeight: 600,
                transition: 'all 0.3s ease',
                '&:hover': {
                  transform: 'translateY(-3px)',
                  boxShadow: '0 10px 20px rgba(67, 97, 238, 0.3)',
                }
              }}
            >
              View Portfolio
            </Button>
          </Box>
          <Box sx={{ textAlign: { xs: 'center', md: 'right' } }}>
            <MotionBox
              ref={animation.ref}
              style={animation.style}
              sx={{
                width: { xs: 220, md: 320 },
                height: { xs: 220, md: 320 },
                borderRadius: '50%',
                overflow: 'hidden',
                boxShadow: '0 20px 30px rgba(0, 0, 0, 0.15)',
                background: theme.palette.mode === 'light' 
                  ? 'linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%)' 
                  : 'linear-gradient(135deg, #3f37c9 0%, #4361ee 100%)',
                padding: '5px',
                margin: '0 auto'
              }}
            >
              <Box
                component="img"
                src="/logoP.png"
                alt="Profile"
                sx={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  borderRadius: '50%',
                  border: '4px solid white',
                }}
              />
            </MotionBox>
          </Box>
        </Stack>
      </Container>
    </Box>
  );
}; 