import React from 'react';
import { motion } from 'framer-motion';

const pageVariants = {
  initial: {
    opacity: 0,
    y: 30,
    scale: 0.98
  },
  in: {
    opacity: 1,
    y: 0,
    scale: 1
  },
  exit: {
    opacity: 0,
    y: -20,
    scale: 0.98
  }
};

const pageTransition = {
  type: 'tween',
  ease: [0.25, 0.1, 0.25, 1], // cubic-bezier
  duration: 0.6
};

interface PageAnimationProps {
  children: React.ReactNode;
}

const PageAnimation: React.FC<PageAnimationProps> = ({ children }) => {
  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="exit"
      variants={pageVariants}
      transition={pageTransition}
      style={{ 
        width: '100%',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      {children}
    </motion.div>
  );
};

export default PageAnimation; 