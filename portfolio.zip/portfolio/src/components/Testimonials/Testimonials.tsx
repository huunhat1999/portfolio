import React from 'react';
import { Box, Container, Typography, Card, CardContent, Avatar, Grid, useTheme, Rating } from '@mui/material';
import { motion } from 'framer-motion';
import FormatQuoteIcon from '@mui/icons-material/FormatQuote';

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'CEO, TechStart',
    image: 'https://randomuser.me/api/portraits/women/32.jpg',
    content: 'Working with Trần has been an absolute pleasure. His technical expertise and attention to detail transformed our website into something truly special. Our conversion rates have increased by 40% since the launch.',
    rating: 5,
  },
  {
    name: 'David Chen',
    role: 'Marketing Director, InnovateCorp',
    image: 'https://randomuser.me/api/portraits/men/44.jpg',
    content: 'We hired Trần to redesign our e-commerce platform, and the results were beyond our expectations. The site is not only beautiful but also performs exceptionally well. Our page load times decreased by 65%!',
    rating: 5,
  },
  {
    name: 'Lisa Rodriguez',
    role: 'Founder, ArtisanCraft',
    image: 'https://randomuser.me/api/portraits/women/68.jpg',
    content: 'As a small business owner, I needed a developer who understood my vision and could work within my budget. Trần delivered a stunning website that perfectly captures our brand identity. Highly recommended!',
    rating: 4.5,
  },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { y: 20, opacity: 0 },
  show: { 
    y: 0, 
    opacity: 1,
    transition: {
      duration: 0.5,
      ease: "easeOut"
    }
  }
};

export const Testimonials: React.FC = () => {
  const theme = useTheme();

  return (
    <Box
      component="section"
      id="testimonials"
      sx={{
        py: 12,
        backgroundColor: theme.palette.mode === 'light'
          ? 'rgba(248, 250, 252, 0.8)'
          : theme.palette.background.default,
        position: 'relative',
        '&::before': theme.palette.mode === 'light' ? {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundImage: 'radial-gradient(circle at 30% 70%, rgba(67, 97, 238, 0.07) 0%, transparent 70%)',
          zIndex: 0,
        } : {},
      }}
    >
      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Typography
          variant="h2"
          component="h2"
          align="center"
          gutterBottom
          sx={{
            fontSize: { xs: '2rem', md: '2.5rem' },
            fontWeight: 700,
            color: theme.palette.primary.main,
            mb: 1,
            position: 'relative',
            display: 'inline-block',
            margin: '0 auto',
            textAlign: 'center',
            width: '100%',
            '&::after': {
              content: '""',
              position: 'absolute',
              bottom: -8,
              left: '50%',
              transform: 'translateX(-50%)',
              width: '80px',
              height: '4px',
              background: theme.palette.mode === 'light' 
                ? 'linear-gradient(90deg, #4361ee, #4cc9f0)'
                : 'linear-gradient(90deg, #6387ff, #4cc9f0)',
              borderRadius: '2px',
            }
          }}
        >
          CLIENT TESTIMONIALS
        </Typography>
        <Typography
          variant="body1"
          align="center"
          sx={{
            fontSize: '1.1rem',
            color: theme.palette.text.secondary,
            maxWidth: '700px',
            margin: '1.5rem auto 4rem',
          }}
        >
          Here's what clients are saying about working with me
        </Typography>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          <Grid container spacing={4}>
            {testimonials.map((testimonial, index) => (
              <Grid item xs={12} md={4} key={index}>
                <motion.div variants={item}>
                  <Card
                    sx={{
                      height: '100%',
                      display: 'flex',
                      flexDirection: 'column',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      boxShadow: theme.palette.mode === 'light' 
                        ? '0 10px 30px rgba(67, 97, 238, 0.1)' 
                        : '0 10px 30px rgba(0, 0, 0, 0.2)',
                      position: 'relative',
                    }}
                  >
                    <CardContent sx={{ p: 4, flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                      <Box sx={{ position: 'absolute', top: 20, right: 20, opacity: 0.1, color: theme.palette.primary.main }}>
                        <FormatQuoteIcon sx={{ fontSize: 70 }} />
                      </Box>
                      
                      <Typography 
                        variant="body1" 
                        sx={{ 
                          mb: 3, 
                          fontStyle: 'italic',
                          lineHeight: 1.6,
                          flexGrow: 1,
                          position: 'relative',
                          zIndex: 1
                        }}
                      >
                        "{testimonial.content}"
                      </Typography>
                      
                      <Box sx={{ display: 'flex', alignItems: 'center', mt: 'auto' }}>
                        <Avatar 
                          src={testimonial.image} 
                          alt={testimonial.name}
                          sx={{ 
                            width: 60, 
                            height: 60,
                            mr: 2,
                            border: `2px solid ${theme.palette.primary.main}`
                          }}
                        />
                        <Box>
                          <Typography variant="subtitle1" fontWeight={600}>
                            {testimonial.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary" gutterBottom>
                            {testimonial.role}
                          </Typography>
                          <Rating 
                            value={testimonial.rating} 
                            precision={0.5} 
                            readOnly 
                            size="small"
                          />
                        </Box>
                      </Box>
                    </CardContent>
                  </Card>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        </motion.div>
      </Container>
    </Box>
  );
}; 