import React from 'react';
import { Box, Container, Typography, Link, Divider, Stack, IconButton, Grid } from '@mui/material';
import GitHubIcon from '@mui/icons-material/GitHub';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import EmailIcon from '@mui/icons-material/Email';
import TwitterIcon from '@mui/icons-material/Twitter';
import PhoneIcon from '@mui/icons-material/Phone';

export const Footer: React.FC = () => {
  return (
    <Box
      component="footer"
      sx={{
        py: 3,
        px: 2,
        mt: 'auto',
        backgroundColor: theme => theme.palette.background.paper,
        borderColor: 'divider',
      }}
    >
      <Container maxWidth="lg">
        <Divider sx={{ mb: 3 }} />
        
        <Grid container spacing={3} mb={3}>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Get In Touch
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <EmailIcon sx={{ mr: 1 }} fontSize="small" />
              <Typography variant="body2">
                lifeofdev.thn@gmail.com
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <PhoneIcon sx={{ mr: 1 }} fontSize="small" />
              <Typography variant="body2">
                +84 38 650 1426
              </Typography>
            </Box>
          </Grid>
          
          <Grid item xs={12} md={6} sx={{ display: 'flex', flexDirection: 'column', alignItems: { xs: 'flex-start', md: 'flex-end' } }}>
            <Typography variant="h6" gutterBottom>
              Follow Me
            </Typography>
            <Stack direction="row" spacing={1}>
              <IconButton
                color="primary"
                aria-label="GitHub"
                component={Link}
                href="https://github.com/yourusername"
                target="_blank"
                rel="noopener noreferrer"
              >
                <GitHubIcon />
              </IconButton>
              <IconButton
                color="primary"
                aria-label="LinkedIn"
                component={Link}
                href="https://linkedin.com/in/yourusername"
                target="_blank"
                rel="noopener noreferrer"
              >
                <LinkedInIcon />
              </IconButton>
              <IconButton
                color="primary"
                aria-label="Twitter"
                component={Link}
                href="https://twitter.com/yourusername"
                target="_blank"
                rel="noopener noreferrer"
              >
                <TwitterIcon />
              </IconButton>
              <IconButton
                color="primary"
                aria-label="Email"
                component={Link}
                href="mailto:nguyenvana@example.com"
              >
                <EmailIcon />
              </IconButton>
            </Stack>
          </Grid>
        </Grid>
        
        <Stack
          direction={{ xs: 'column', md: 'row' }}
          justifyContent="space-between"
          alignItems="center"
          spacing={2}
        >
          <Typography variant="body2" color="text.secondary">
            © {new Date().getFullYear()} Nhật Smile . All rights reserved.
          </Typography>
        </Stack>
      </Container>
    </Box>
  );
}; 