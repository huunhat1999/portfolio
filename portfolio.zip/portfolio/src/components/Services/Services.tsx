import React from 'react';
import { Box, Container, Typography, Grid, Card, CardContent, useTheme } from '@mui/material';
import { motion } from 'framer-motion';
import CodeIcon from '@mui/icons-material/Code';
import DevicesIcon from '@mui/icons-material/Devices';
import SpeedIcon from '@mui/icons-material/Speed';
import BrushIcon from '@mui/icons-material/Brush';
import StorageIcon from '@mui/icons-material/Storage';
import AnalyticsIcon from '@mui/icons-material/Analytics';

const services = [
  {
    title: 'Web Development',
    description: 'Custom websites with modern technologies focusing on performance and user experience.',
    icon: <CodeIcon fontSize="large" />,
  },
  {
    title: 'Responsive Design',
    description: 'Fluid designs that work perfectly on all devices, from desktops to mobiles.',
    icon: <DevicesIcon fontSize="large" />,
  },
  {
    title: 'Performance Optimization',
    description: 'Speed up your website for better user experience and SEO rankings.',
    icon: <SpeedIcon fontSize="large" />,
  },
  {
    title: 'UI/UX Design',
    description: 'Intuitive and attractive interfaces that enhance user satisfaction.',
    icon: <BrushIcon fontSize="large" />,
  },
  {
    title: 'Backend Integration',
    description: 'Connect your frontend to robust APIs and databases for full functionality.',
    icon: <StorageIcon fontSize="large" />,
  },
  {
    title: 'Analytics & SEO',
    description: 'Implement analytics tracking and optimize your site for search engines.',
    icon: <AnalyticsIcon fontSize="large" />,
  },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { y: 20, opacity: 0 },
  show: { 
    y: 0, 
    opacity: 1,
    transition: {
      duration: 0.5,
      ease: "easeOut"
    }
  }
};

export const Services: React.FC = () => {
  const theme = useTheme();

  return (
    <Box
      component="section"
      id="services"
      sx={{
        py: 12,
        backgroundColor: theme.palette.mode === 'light'
          ? theme.palette.background.paper
          : 'linear-gradient(180deg, rgba(15, 23, 42, 1) 0%, rgba(30, 41, 59, 0.95) 100%)',
        position: 'relative',
        '&::before': theme.palette.mode === 'light' ? {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundImage: 'radial-gradient(circle at 80% 20%, rgba(67, 97, 238, 0.07) 0%, transparent 70%)',
          zIndex: 0,
        } : {},
      }}
    >
      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Typography
          variant="h2"
          component="h2"
          align="center"
          gutterBottom
          sx={{
            fontSize: { xs: '2rem', md: '2.5rem' },
            fontWeight: 700,
            color: theme.palette.primary.main,
            mb: 1,
            position: 'relative',
            display: 'inline-block',
            margin: '0 auto',
            textAlign: 'center',
            width: '100%',
            '&::after': {
              content: '""',
              position: 'absolute',
              bottom: -8,
              left: '50%',
              transform: 'translateX(-50%)',
              width: '80px',
              height: '4px',
              background: theme.palette.mode === 'light' 
                ? 'linear-gradient(90deg, #4361ee, #4cc9f0)'
                : 'linear-gradient(90deg, #6387ff, #4cc9f0)',
              borderRadius: '2px',
            }
          }}
        >
          SERVICES
        </Typography>
        <Typography
          variant="body1"
          align="center"
          sx={{
            fontSize: '1.1rem',
            color: theme.palette.text.secondary,
            maxWidth: '700px',
            margin: '1.5rem auto 4rem',
          }}
        >
          Here are the services I offer to help bring your digital ideas to life
        </Typography>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          <Grid container spacing={4}>
            {services.map((service, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <motion.div variants={item}>
                  <Card
                    sx={{
                      height: '100%',
                      display: 'flex',
                      flexDirection: 'column',
                      borderRadius: '16px',
                      overflow: 'hidden',
                      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                      '&:hover': {
                        transform: 'translateY(-8px)',
                        boxShadow: theme.palette.mode === 'light' 
                          ? '0 15px 30px rgba(67, 97, 238, 0.1)' 
                          : '0 15px 30px rgba(0, 0, 0, 0.2)',
                      },
                      position: 'relative',
                      '&::before': theme.palette.mode === 'light' ? {
                        content: '""',
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '4px',
                        background: 'linear-gradient(90deg, #4361ee, #4cc9f0)',
                      } : {},
                    }}
                  >
                    <CardContent sx={{ flexGrow: 1, p: 4, textAlign: 'center' }}>
                      <Box
                        sx={{
                          display: 'flex',
                          justifyContent: 'center',
                          alignItems: 'center',
                          mb: 2,
                          width: 70,
                          height: 70,
                          borderRadius: '50%',
                          backgroundColor: 'rgba(67, 97, 238, 0.1)',
                          color: theme.palette.primary.main,
                          margin: '0 auto 1.5rem',
                        }}
                      >
                        {service.icon}
                      </Box>
                      <Typography
                        variant="h5"
                        component="h3"
                        gutterBottom
                        fontWeight={600}
                        sx={{ mb: 2 }}
                      >
                        {service.title}
                      </Typography>
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{ lineHeight: 1.6 }}
                      >
                        {service.description}
                      </Typography>
                    </CardContent>
                  </Card>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        </motion.div>
      </Container>
    </Box>
  );
}; 