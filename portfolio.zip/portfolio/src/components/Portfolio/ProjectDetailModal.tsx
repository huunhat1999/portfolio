import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Typography,
  Box,
  Chip,
  Stack,
  Link,
  useTheme,
  useMediaQuery,
  Divider,
  Grid,
  List,
  ListItem,
  ListItemIcon,
  ListItemText
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import CodeIcon from '@mui/icons-material/Code';
import BuildIcon from '@mui/icons-material/Build';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import { Project } from '../../types';

interface ProjectDetailModalProps {
  project: Project | null;
  open: boolean;
  onClose: () => void;
  disableEscapeKeyDown?: boolean;
  hideBackdrop?: boolean;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  open,
  onClose,
  disableEscapeKeyDown = false,
  hideBackdrop = false
}) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

  if (!project) return null;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullScreen={fullScreen}
      maxWidth="md"
      fullWidth
      disableEscapeKeyDown={disableEscapeKeyDown}
      hideBackdrop={hideBackdrop}
      transitionDuration={300}
      PaperProps={{
        sx: {
          borderRadius: fullScreen ? 0 : '16px',
          background: theme.palette.mode === 'light'
            ? 'rgba(255, 255, 255, 0.9)'
            : 'rgba(30, 41, 59, 0.95)',
          backdropFilter: 'blur(10px)',
          zIndex: 1000, // Ensure it appears above other elements
        }
      }}
      sx={{
        zIndex: 1300, // Higher than default Dialog zIndex
      }}
    >
      <DialogTitle sx={{ 
        m: 0, 
        p: 2,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="h5" component="h2" sx={{ fontWeight: 600 }}>
          {project.title}
        </Typography>
        <IconButton
          aria-label="close"
          onClick={onClose}
          disabled={disableEscapeKeyDown} // Disable close button during transitions
          sx={{
            color: theme.palette.text.secondary,
            '&:hover': {
              color: theme.palette.primary.main
            }
          }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent dividers>
        <Box sx={{ mb: 4 }}>
          <img
            src={project.image}
            alt={project.title}
            style={{
              width: '100%',
              height: 'auto',
              maxHeight: '400px',
              objectFit: 'cover',
              borderRadius: '8px'
            }}
          />
        </Box>
        
        <Typography variant="body1" paragraph sx={{ lineHeight: 1.8 }}>
          {project.longDescription || project.description}
        </Typography>

        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={4}>
            <Box sx={{ 
              p: 2, 
              borderRadius: '8px',
              bgcolor: theme.palette.mode === 'light' 
                ? 'rgba(67, 97, 238, 0.05)' 
                : 'rgba(67, 97, 238, 0.1)',
              height: '100%'
            }}>
              <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                My Role
              </Typography>
              <Typography variant="body2">
                {project.role || 'Full Stack Developer'}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ 
              p: 2, 
              borderRadius: '8px',
              bgcolor: theme.palette.mode === 'light' 
                ? 'rgba(67, 97, 238, 0.05)' 
                : 'rgba(67, 97, 238, 0.1)',
              height: '100%'
            }}>
              <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                Duration
              </Typography>
              <Typography variant="body2">
                {project.duration || '3 months'}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ 
              p: 2, 
              borderRadius: '8px',
              bgcolor: theme.palette.mode === 'light' 
                ? 'rgba(67, 97, 238, 0.05)' 
                : 'rgba(67, 97, 238, 0.1)',
              height: '100%'
            }}>
              <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                Team Size
              </Typography>
              <Typography variant="body2">
                {project.teamSize || 'Solo project'}
              </Typography>
            </Box>
          </Grid>
        </Grid>

        <Divider sx={{ my: 3 }} />

        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
            <BuildIcon sx={{ mr: 1, color: theme.palette.primary.main }} />
            Technologies Used
          </Typography>
          <Stack direction="row" spacing={1} flexWrap="wrap">
            {project.technologies.map((tech) => (
              <Chip
                key={tech}
                label={tech}
                sx={{
                  bgcolor: theme.palette.mode === 'light' 
                    ? 'rgba(67, 97, 238, 0.08)'
                    : 'rgba(67, 97, 238, 0.15)',
                  color: theme.palette.primary.main,
                  fontWeight: 500,
                  mr: 1,
                  mb: 1,
                  borderRadius: '6px'
                }}
              />
            ))}
          </Stack>
        </Box>

        {project.keyFeatures && project.keyFeatures.length > 0 && (
          <Box sx={{ mb: 4 }}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
              <CodeIcon sx={{ mr: 1, color: theme.palette.primary.main }} />
              Key Features
            </Typography>
            <List>
              {project.keyFeatures.map((feature, index) => (
                <ListItem key={index} sx={{ py: 0.5 }}>
                  <ListItemIcon sx={{ minWidth: 36 }}>
                    <CheckCircleOutlineIcon sx={{ color: theme.palette.primary.main }} />
                  </ListItemIcon>
                  <ListItemText primary={feature} />
                </ListItem>
              ))}
            </List>
          </Box>
        )}

        {project.challenges && project.solutions && (
          <Box sx={{ mb: 4 }}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 600, display: 'flex', alignItems: 'center' }}>
              <LightbulbIcon sx={{ mr: 1, color: theme.palette.primary.main }} />
              Challenges & Solutions
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Challenges
                </Typography>
                <List>
                  {project.challenges.map((challenge, index) => (
                    <ListItem key={index} sx={{ py: 0.5 }}>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <CheckCircleOutlineIcon sx={{ color: theme.palette.error.main }} />
                      </ListItemIcon>
                      <ListItemText primary={challenge} />
                    </ListItem>
                  ))}
                </List>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                  Solutions
                </Typography>
                <List>
                  {project.solutions.map((solution, index) => (
                    <ListItem key={index} sx={{ py: 0.5 }}>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <CheckCircleOutlineIcon sx={{ color: theme.palette.success.main }} />
                      </ListItemIcon>
                      <ListItemText primary={solution} />
                    </ListItem>
                  ))}
                </List>
              </Grid>
            </Grid>
          </Box>
        )}

        <Divider sx={{ my: 3 }} />

        <Stack direction="row" spacing={3} justifyContent="center">
          {project.link && (
            <Link
              href={project.link}
              target="_blank"
              rel="noopener noreferrer"
              underline="hover"
              color="primary"
              fontWeight={600}
              sx={{ 
                display: 'flex',
                alignItems: 'center',
                '&:hover': {
                  color: theme.palette.primary.light
                }
              }}
            >
              View Live Demo
            </Link>
          )}
          {project.github && (
            <Link
              href={project.github}
              target="_blank"
              rel="noopener noreferrer"
              underline="hover"
              color="primary"
              fontWeight={600}
              sx={{ 
                display: 'flex',
                alignItems: 'center',
                '&:hover': {
                  color: theme.palette.primary.light
                }
              }}
            >
              View on GitHub
            </Link>
          )}
        </Stack>
      </DialogContent>
    </Dialog>
  );
}; 