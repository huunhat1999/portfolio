import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Card, 
  CardContent, 
  CardMedia, 
  Link, 
  Chip,
  Stack,
  useTheme 
} from '@mui/material';
import { motion } from 'framer-motion';
import { useComponentAnimation } from '../../hooks/useComponentAnimation';
import { projects } from '../../entity/project';
import { ProjectDetailModal } from './ProjectDetailModal';
import { PageHeader } from '../PageHeader/PageHeader';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { y: 20, opacity: 0 },
  show: { 
    y: 0, 
    opacity: 1,
    transition: {
      duration: 0.5,
      ease: "easeOut"
    }
  }
};

export const Portfolio: React.FC = () => {
  const theme = useTheme();
  const titleAnimation = useComponentAnimation();
  const MotionCard = motion(Card);
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);
  const [isModalTransitioning, setIsModalTransitioning] = useState(false);

  const handleProjectClick = (project: typeof projects[0]) => {
    if (selectedProject || isModalTransitioning) return;
    
    setIsModalTransitioning(true);
    setSelectedProject(project);
    
    setTimeout(() => {
      setIsModalTransitioning(false);
    }, 300);
  };

  const handleCloseModal = () => {
    if (isModalTransitioning) return;
    
    setIsModalTransitioning(true);
    setSelectedProject(null);
    
    setTimeout(() => {
      setIsModalTransitioning(false);
    }, 300);
  };

  return (
    <Box
      id="portfolio"
      component="section"
      sx={{
        py: 12,
        backgroundColor: theme.palette.mode === 'light' 
          ? theme.palette.background.default
          : 'linear-gradient(180deg, rgba(15, 23, 42, 1) 0%, rgba(30, 41, 59, 0.95) 100%)',
        position: 'relative',
        '&::before': theme.palette.mode === 'light' ? {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundImage: 'radial-gradient(circle at 20% 30%, rgba(67, 97, 238, 0.07) 0%, transparent 70%)',
          zIndex: 0,
        } : {},
      }}
    >
      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Box ref={titleAnimation.ref} style={titleAnimation.style}>
        <PageHeader 
            title="MY PROJECTS" 
            subtitle=" Check out some of my recent work and the technologies I've been using"
          />
         
        </Box>
        
        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
        >
          <Box sx={{ display: 'flex', flexWrap: 'wrap', margin: -2 }}>
            {projects.map((project) => (
              <Box
                key={project.id}
                sx={{ 
                  width: { xs: '100%', sm: '50%', md: '33.333%' },
                  padding: 2
                }}
              >
                <motion.div variants={item}>
                  <MotionCard
                    onClick={() => handleProjectClick(project)}
                    sx={{
                      height: '100%',
                      display: 'flex',
                      flexDirection: 'column',
                      overflow: 'hidden',
                      borderRadius: '16px',
                      transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
                      cursor: selectedProject || isModalTransitioning ? 'default' : 'pointer',
                      opacity: selectedProject && selectedProject.id !== project.id ? 0.7 : 1,
                      pointerEvents: selectedProject || isModalTransitioning ? 'none' : 'auto',
                      '&:hover': {
                        transform: selectedProject || isModalTransitioning 
                          ? 'none' 
                          : 'translateY(-8px)',
                        boxShadow: selectedProject || isModalTransitioning
                          ? 'none'
                          : theme.palette.mode === 'light' 
                            ? '0 15px 30px rgba(67, 97, 238, 0.1)' 
                            : '0 15px 30px rgba(0, 0, 0, 0.2)',
                        '& .MuiCardMedia-root': {
                          transform: selectedProject || isModalTransitioning 
                            ? 'none' 
                            : 'scale(1.05)'
                        }
                      }
                    }}
                  >
                    <Box sx={{ position: 'relative', overflow: 'hidden' }}>
                      <CardMedia
                        component="img"
                        height="220"
                        image={project.image}
                        alt={project.title}
                        sx={{ 
                          objectFit: 'cover',
                          transition: 'transform 0.6s ease'
                        }}
                      />
                      <Box 
                        sx={{ 
                          position: 'absolute', 
                          top: 0, 
                          left: 0, 
                          width: '100%', 
                          height: '100%',
                          background: theme.palette.mode === 'light'
                            ? 'linear-gradient(to top, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0) 40%)'
                            : 'linear-gradient(to top, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0) 40%)'
                        }}
                      />
                    </Box>
                    <CardContent sx={{ flexGrow: 1, p: 3 }}>
                      <Typography
                        variant="h5"
                        component="h3"
                        gutterBottom
                        sx={{
                          fontWeight: 600,
                          color: theme.palette.primary.main,
                          mb: 1
                        }}
                      >
                        {project.title}
                      </Typography>
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        paragraph
                        sx={{ mb: 2, lineHeight: 1.6 }}
                      >
                        {project.description}
                      </Typography>
                      <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mb: 3 }}>
                        {project.technologies.map((tech) => (
                          <Chip
                            key={tech}
                            label={tech}
                            size="small"
                            sx={{
                              bgcolor: theme.palette.mode === 'light' 
                                ? 'rgba(67, 97, 238, 0.08)'
                                : 'rgba(67, 97, 238, 0.15)',
                              color: theme.palette.primary.main,
                              fontWeight: 500,
                              mr: 1,
                              mb: 1,
                              borderRadius: '6px'
                            }}
                          />
                        ))}
                      </Stack>
                      <Stack direction="row" spacing={3}>
                        {project.link && (
                          <Link
                            href={project.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            underline="hover"
                            color="primary"
                            fontWeight={600}
                            onClick={(e) => e.stopPropagation()}
                            sx={{ 
                              display: 'flex',
                              alignItems: 'center',
                              '&:hover': {
                                color: theme.palette.primary.light
                              }
                            }}
                          >
                            Live Demo
                          </Link>
                        )}
                        {project.github && (
                          <Link
                            href={project.github}
                            target="_blank"
                            rel="noopener noreferrer"
                            underline="hover"
                            color="primary"
                            fontWeight={600}
                            onClick={(e) => e.stopPropagation()}
                            sx={{ 
                              display: 'flex',
                              alignItems: 'center',
                              '&:hover': {
                                color: theme.palette.primary.light
                              }
                            }}
                          >
                            GitHub
                          </Link>
                        )}
                      </Stack>
                    </CardContent>
                  </MotionCard>
                </motion.div>
              </Box>
            ))}
          </Box>
        </motion.div>
      </Container>

      <ProjectDetailModal
        project={selectedProject}
        open={!!selectedProject}
        onClose={handleCloseModal}
        disableEscapeKeyDown={isModalTransitioning}
        hideBackdrop={isModalTransitioning && !selectedProject}
      />
    </Box>
  );
}; 