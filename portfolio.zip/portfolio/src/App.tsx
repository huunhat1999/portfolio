import React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import { BrowserRouter, useRoutes, useLocation } from 'react-router-dom';
import { ThemeProvider } from './styles/ThemeContext';
import { ScrollToTop } from './components/ScrollToTop/ScrollToTop';
import { routes } from './routes';
import { AnimatePresence } from 'framer-motion';


const AppRoutes: React.FC = () => {
  const element = useRoutes(routes);
  const location = useLocation();
  
  return (
    <AnimatePresence mode="wait">
      {element && React.cloneElement(element, { key: location.pathname })}
    </AnimatePresence>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <CssBaseline />
      <BrowserRouter>
        <ScrollToTop />
        <AppRoutes />
      </BrowserRouter>
    </ThemeProvider>
  );
};

export default App; 