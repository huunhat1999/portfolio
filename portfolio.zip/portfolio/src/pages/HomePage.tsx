import React from 'react';
import { Hero } from '../components/Hero/Hero';
import { Skills } from '../components/Skills/Skills';
import { Portfolio } from '../components/Portfolio/Portfolio';
import PageAnimation from '../components/PageAnimation/PageAnimation';
import { Services } from '../components/Services/Services';
import { Statistics } from '../components/Statistics/Statistics';
import { Testimonials } from '../components/Testimonials/Testimonials';
import { CTA } from '../components/CTA/CTA';

export const HomePage: React.FC = () => {
  return (
    <PageAnimation>
      <Hero />
      <Skills />
      <Services />
      <Statistics />
      <Portfolio />
      <CTA />
    </PageAnimation>
  );
}; 