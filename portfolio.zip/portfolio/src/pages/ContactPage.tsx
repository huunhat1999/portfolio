import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  TextField, 
  Button, 
  Card, 
  CardContent, 
  Stack, 
  useTheme,
  Snackbar,
  Alert,
  Paper,
  IconButton 
} from '@mui/material';
import { motion } from 'framer-motion';
import PageAnimation from '../components/PageAnimation/PageAnimation';
import { useComponentAnimation } from '../hooks/useComponentAnimation';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import SendIcon from '@mui/icons-material/Send';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import GitHubIcon from '@mui/icons-material/GitHub';
import TwitterIcon from '@mui/icons-material/Twitter';
import { PageHeader } from '../components/PageHeader/PageHeader';

interface FormValues {
  name: string;
  email: string;
  subject: string;
  message: string;
}

const initialFormValues: FormValues = {
  name: '',
  email: '',
  subject: '',
  message: ''
};

export const ContactPage: React.FC = () => {
  const theme = useTheme();
  const formAnimation = useComponentAnimation({ delay: 0.2 });
  const infoAnimation = useComponentAnimation({ delay: 0.3 });
  
  const [formValues, setFormValues] = useState<FormValues>(initialFormValues);
  const [formErrors, setFormErrors] = useState<Partial<FormValues>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({ ...prev, [name]: value }));
    if (formErrors[name as keyof FormValues]) {
      setFormErrors(prev => ({ ...prev, [name]: undefined }));  
    }
  };

  const validate = () => {
    const errors: Partial<FormValues> = {};
    
    if (!formValues.name.trim()) {
      errors.name = 'Name is required';
    }
    
    if (!formValues.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(formValues.email)) {
      errors.email = 'Invalid email address';
    }
    
    if (!formValues.subject.trim()) {
      errors.subject = 'Subject is required';
    }
    
    if (!formValues.message.trim()) {
      errors.message = 'Message is required';
    }
    
    return errors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const errors = validate();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      console.log('Form submitted:', formValues);
      setFormValues(initialFormValues);
      setIsSubmitting(false);
      setSnackbar({
        open: true,
        message: 'Message sent successfully! I will get back to you soon.',
        severity: 'success'
      });
    }, 1500);
  };

  const handleCloseSnackbar = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbar(prev => ({ ...prev, open: false }));
  };

  const MotionPaper = motion(Paper);

  return (
    <PageAnimation>
      <Box
        sx={{
          py: 12,
          position: 'relative',
          backgroundColor: theme.palette.mode === 'light' 
            ? 'rgba(248, 250, 252, 0.8)'
            : theme.palette.background.paper,
          '&::before': theme.palette.mode === 'light' ? {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundImage: 'radial-gradient(circle at 70% 30%, rgba(67, 97, 238, 0.07) 0%, transparent 70%)',
            zIndex: 0,
          } : {},
        }}
      >
        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
          <PageHeader 
            title="GET IN TOUCH" 
            subtitle="Have a question or want to work together? Feel free to contact me!"
          />

          <Grid container spacing={5}>
            <Grid item xs={12} md={7}>
              <Box ref={formAnimation.ref} style={formAnimation.style}>
                <Card
                  elevation={0}
                  sx={{ 
                    borderRadius: '16px',
                    overflow: 'hidden',
                    boxShadow: theme.palette.mode === 'light' 
                      ? '0 15px 30px rgba(67, 97, 238, 0.1)' 
                      : '0 15px 30px rgba(0, 0, 0, 0.2)',
                  }}
                >
                  <CardContent sx={{ p: 4 }}>
                    <Typography variant="h5" component="h2" fontWeight={600} gutterBottom>
                      Send Me a Message
                    </Typography>
                    <form onSubmit={handleSubmit}>
                      <Grid container spacing={3}>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            fullWidth
                            label="Your Name"
                            name="name"
                            value={formValues.name}
                            onChange={handleChange}
                            error={!!formErrors.name}
                            helperText={formErrors.name}
                            variant="outlined"
                            required
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            fullWidth
                            label="Your Email"
                            name="email"
                            type="email"
                            value={formValues.email}
                            onChange={handleChange}
                            error={!!formErrors.email}
                            helperText={formErrors.email}
                            variant="outlined"
                            required
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <TextField
                            fullWidth
                            label="Subject"
                            name="subject"
                            value={formValues.subject}
                            onChange={handleChange}
                            error={!!formErrors.subject}
                            helperText={formErrors.subject}
                            variant="outlined"
                            required
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <TextField
                            fullWidth
                            label="Message"
                            name="message"
                            multiline
                            rows={6}
                            value={formValues.message}
                            onChange={handleChange}
                            error={!!formErrors.message}
                            helperText={formErrors.message}
                            variant="outlined"
                            required
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            size="large"
                            disabled={isSubmitting}
                            endIcon={<SendIcon />}
                            sx={{ 
                              py: 1.5,
                              px: 4,
                              fontWeight: 600,
                              borderRadius: '8px',
                              boxShadow: theme.palette.mode === 'light' 
                                ? '0 4px 14px rgba(67, 97, 238, 0.25)'
                                : 'none',
                              '&:hover': {
                                transform: 'translateY(-2px)',
                                boxShadow: '0 6px 20px rgba(67, 97, 238, 0.3)',
                              }
                            }}
                          >
                            {isSubmitting ? 'Sending...' : 'Send Message'}
                          </Button>
                        </Grid>
                      </Grid>
                    </form>
                  </CardContent>
                </Card>
              </Box>
            </Grid>
                            
            <Grid item xs={12} md={5}>
              <Box ref={infoAnimation.ref} style={infoAnimation.style}>
                <Stack spacing={3}>
                  <MotionPaper
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4, duration: 0.5 }}
                    elevation={0}
                    sx={{ 
                      p: 3,
                      borderRadius: '16px',
                      boxShadow: theme.palette.mode === 'light' 
                        ? '0 15px 30px rgba(67, 97, 238, 0.1)' 
                        : '0 15px 30px rgba(0, 0, 0, 0.2)',
                      background: theme.palette.mode === 'light'
                        ? 'linear-gradient(135deg, rgba(67, 97, 238, 0.08) 0%, rgba(76, 201, 240, 0.1) 100%)'
                        : 'linear-gradient(135deg, rgba(67, 97, 238, 0.2) 0%, rgba(30, 41, 59, 1) 100%)',
                    }}
                  >
                    <Typography variant="h5" component="h3" fontWeight={600} gutterBottom>
                      Contact Information
                    </Typography>
                    <Stack spacing={3} sx={{ mt: 3 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Box
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: 45,
                            height: 45,
                            borderRadius: '12px',
                            backgroundColor: 'rgba(67, 97, 238, 0.15)',
                            color: theme.palette.primary.main,
                            mr: 2
                          }}
                        >
                          <EmailIcon />
                        </Box>
                        <Box>
                          <Typography variant="body2" color="text.secondary" gutterBottom>
                            Email
                          </Typography>
                          <Typography variant="body1" fontWeight={500}>
                            lifeofdev.thn@gmail.com
                          </Typography>
                        </Box>
                      </Box>

                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Box
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: 45,
                            height: 45,
                            borderRadius: '12px',
                            backgroundColor: 'rgba(67, 97, 238, 0.15)',
                            color: theme.palette.primary.main,
                            mr: 2
                          }}
                        >
                          <PhoneIcon />
                        </Box>
                        <Box>
                          <Typography variant="body2" color="text.secondary" gutterBottom>
                            Phone
                          </Typography>
                          <Typography variant="body1" fontWeight={500}>
                            +84 38 650 1426
                          </Typography>
                        </Box>
                      </Box>

                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Box
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: 45,
                            height: 45,
                            borderRadius: '12px',
                            backgroundColor: 'rgba(67, 97, 238, 0.15)',
                            color: theme.palette.primary.main,
                            mr: 2
                          }}
                        >
                          <LocationOnIcon />
                        </Box>
                        <Box>
                          <Typography variant="body2" color="text.secondary" gutterBottom>
                            Location
                          </Typography>
                          <Typography variant="body1" fontWeight={500}>
                            Ho Chi Minh City, Vietnam
                          </Typography>
                        </Box>
                      </Box>
                    </Stack>
                  </MotionPaper>

                  <MotionPaper
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                    elevation={0}
                    sx={{ 
                      p: 3,
                      borderRadius: '16px',
                      boxShadow: theme.palette.mode === 'light' 
                        ? '0 15px 30px rgba(67, 97, 238, 0.1)' 
                        : '0 15px 30px rgba(0, 0, 0, 0.2)',
                    }}
                  >
                    <Typography variant="h5" component="h3" fontWeight={600} gutterBottom>
                      Follow Me
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 2, mt: 2 }}>
                      <IconButton
                        aria-label="LinkedIn"
                        color="primary"
                        sx={{ 
                          bgcolor: 'rgba(67, 97, 238, 0.1)',
                          '&:hover': {
                            bgcolor: 'rgba(67, 97, 238, 0.15)',
                            transform: 'translateY(-3px)'
                          },
                          transition: 'all 0.3s ease'
                        }}
                        href="https://www.linkedin.com/in/nh%E1%BA%ADt-fly-04147623b/"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <LinkedInIcon />
                      </IconButton>
                      <IconButton
                        aria-label="GitHub"
                        color="primary"
                        sx={{ 
                          bgcolor: 'rgba(67, 97, 238, 0.1)',
                          '&:hover': {
                            bgcolor: 'rgba(67, 97, 238, 0.15)',
                            transform: 'translateY(-3px)'
                          },
                          transition: 'all 0.3s ease'
                        }}
                        href="https://github.com/yourusername"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <GitHubIcon />
                      </IconButton>
                      <IconButton
                        aria-label="Twitter"
                        color="primary"
                        sx={{ 
                          bgcolor: 'rgba(67, 97, 238, 0.1)',
                          '&:hover': {
                            bgcolor: 'rgba(67, 97, 238, 0.15)',
                            transform: 'translateY(-3px)'
                          },
                          transition: 'all 0.3s ease'
                        }}
                        href="https://twitter.com/yourusername"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <TwitterIcon />
                      </IconButton>
                    </Box>
                  </MotionPaper>

                  <MotionPaper
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6, duration: 0.5 }}
                    elevation={0}
                    sx={{ 
                      p: 0,
                      borderRadius: '16px',
                      overflow: 'hidden',
                      boxShadow: theme.palette.mode === 'light' 
                        ? '0 15px 30px rgba(67, 97, 238, 0.1)' 
                        : '0 15px 30px rgba(0, 0, 0, 0.2)',
                      height: '200px'
                    }}
                  >
                    <Box
                      component="iframe"
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.966498115193!2d106.61608787515635!3d10.737065489409318!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752dd9b7f2d5d5%3A0x1f2505211eb44016!2zQ0hVTkcgQ8avIEzDnSBDSEnDilUgSE_DgE5H!5e0!3m2!1svi!2s!4v1746429201614!5m2!1svi!2s"
                      sx={{
                        border: 'none',
                        width: '100%',
                        height: '100%',
                      }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title="Location Map"
                    />
                  </MotionPaper>
                </Stack>
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity} 
          sx={{ width: '100%', boxShadow: '0 8px 16px rgba(0,0,0,0.1)' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </PageAnimation>
  );
}; 