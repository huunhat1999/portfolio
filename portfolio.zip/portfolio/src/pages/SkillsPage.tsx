import React from 'react';
import { Box, Container } from '@mui/material';
import { Skills } from '../components/Skills/Skills';
import PageAnimation from '../components/PageAnimation/PageAnimation';
import { PageHeader } from '../components/PageHeader/PageHeader';

export const SkillsPage: React.FC = () => {
  return (
    <PageAnimation>
      <Box sx={{ py: 8 }}>
        <Container maxWidth="lg">
       
          <Skills />
        </Container>
      </Box>
    </PageAnimation>
  );
}; 