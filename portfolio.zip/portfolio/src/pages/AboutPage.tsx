import React from 'react';
import { Box, Container, Typography, Grid, Card, CardContent, Divider, Avatar, Stack, useTheme, List, ListItem, ListItemIcon, ListItemText, Chip } from '@mui/material';
import PageAnimation from '../components/PageAnimation/PageAnimation';
import { motion } from 'framer-motion';
import { useComponentAnimation } from '../hooks/useComponentAnimation';
import SchoolIcon from '@mui/icons-material/School';
import WorkIcon from '@mui/icons-material/Work';
import PersonIcon from '@mui/icons-material/Person';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import LanguageIcon from '@mui/icons-material/Language';
import SportsSoccerIcon from '@mui/icons-material/SportsSoccer';
import SportsEsportsIcon from '@mui/icons-material/SportsEsports';
import SportsTennisIcon from '@mui/icons-material/SportsTennis';
import GitHubIcon from '@mui/icons-material/GitHub';
import WebIcon from '@mui/icons-material/Web';
import { PageHeader } from '../components/PageHeader/PageHeader';

const item = {
  hidden: { y: 20, opacity: 0 },
  show: { 
    y: 0, 
    opacity: 1,
    transition: {
      duration: 0.5,
      ease: "easeOut"
    }
  }
};

export const AboutPage: React.FC = () => {
  const theme = useTheme();
  const bioAnimation = useComponentAnimation({ delay: 0.2 });
  const eduAnimation = useComponentAnimation({ delay: 0.3 });
  const expAnimation = useComponentAnimation({ delay: 0.4 });
  
  const MotionCard = motion(Card);

  return (
    <PageAnimation>
      <Box 
        sx={{ 
          py: 12,
          position: 'relative',
          backgroundColor: theme.palette.mode === 'light' 
            ? 'rgba(248, 250, 252, 0.8)'
            : theme.palette.background.paper,
          '&::before': theme.palette.mode === 'light' ? {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundImage: 'radial-gradient(circle at 20% 30%, rgba(67, 97, 238, 0.07) 0%, transparent 70%)',
            zIndex: 0,
          } : {},
        }}
      >
        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
          <PageHeader 
            title="ABOUT ME" 
            subtitle="Get to know more about me, my background, and what drives me"
          />

          <Grid container spacing={5}>
            <Grid item xs={12} md={4}>
              <Stack spacing={4}>
                <MotionCard
                  variants={item}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  sx={{ borderRadius: '16px', overflow: 'hidden', p: 3, alignItems: 'center', display: 'flex', flexDirection: 'column' }}
                >
                  <Avatar
                    src="/logoP.png"
                    alt="Trần Hữu Nhật"
                    sx={{ width: 120, height: 120, mb: 2, border: `4px solid ${theme.palette.primary.main}` }}
                  />
                  <Typography variant="h5" fontWeight={700} align="center" gutterBottom>
                    TRẦN HỮU NHẬT
                  </Typography>
                  <Typography variant="subtitle1" color="primary" align="center" gutterBottom>
                    Front-end Developer
                  </Typography>
                  <Divider sx={{ my: 2, width: '100%' }} />
                  <Stack spacing={1} sx={{ width: '100%' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <PhoneIcon sx={{ mr: 1 }} fontSize="small" />
                      <Typography variant="body2">038 650 1426</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <EmailIcon sx={{ mr: 1 }} fontSize="small" />
                      <Typography variant="body2">lifeofdev.thn@gmail.com</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <LocationOnIcon sx={{ mr: 1 }} fontSize="small" />
                      <Typography variant="body2">Lô B, Chung cư Lý Chiêu Hoàng P. An Lạc, Q. Bình Tân</Typography>
                    </Box>
                  </Stack>
                </MotionCard>

                <MotionCard
                  variants={item}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  sx={{ borderRadius: '16px', overflow: 'hidden', p: 3 }}
                >
                  <Typography variant="h6" fontWeight={700} gutterBottom>
                    Education
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Typography variant="body2" fontWeight={600}>
                    Software technology
                  </Typography>
                  <Typography variant="body2">
                    Cao Thang Technical College
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    2017 - 2020
                  </Typography>
                </MotionCard>

                <MotionCard
                  variants={item}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  sx={{ borderRadius: '16px', overflow: 'hidden', p: 3 }}
                >
                  <Typography variant="h6" fontWeight={700} gutterBottom>
                    Skills
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Typography variant="subtitle2" fontWeight={600} gutterBottom>Language / Library</Typography>
                  <Stack direction="row"  flexWrap="wrap" mb={1} gap={1}>
                    <Chip label="HTML5" />
                    <Chip label="CSS3" />
                    <Chip label="JavaScript (ES6+)" />
                    <Chip label="TypeScript" />
                    <Chip label="ReactJS" />
                    <Chip label="Next.js" />
                    <Chip label="React Native" />
                    <Chip label="Redux" />
                    <Chip label="Zustand" />
                    <Chip label="React Query" />
                    <Chip label="React Hook Form" />
                  </Stack>
                  <Typography variant="subtitle2" fontWeight={600} gutterBottom>Tools & Processes</Typography>
                  <Stack direction="row"  flexWrap="wrap" mb={1} gap={1}>
                    <Chip label="Git" />
                    <Chip label="GitHub" />
                    <Chip label="GitLab" />
                    <Chip label="RESTful APIs" />
                    <Chip label="Axios" />
                    <Chip label="Agile" />
                    <Chip label="Scrum" />
                  </Stack>
                  <Typography variant="subtitle2" fontWeight={600} gutterBottom>Dev Tools</Typography>
                  <Stack direction="row" spacing={1} flexWrap="wrap">
                    <Chip label="Figma (convert UI to code)" />
                  </Stack>
                </MotionCard>

                <MotionCard
                  variants={item}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  sx={{ borderRadius: '16px', overflow: 'hidden', p: 3 }}
                >
                  <Typography variant="h6" fontWeight={700} gutterBottom>
                    Interest
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Stack direction="row" spacing={2}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <SportsSoccerIcon sx={{ mr: 1 }} />
                      <Typography variant="body2">Play football</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <SportsTennisIcon sx={{ mr: 1 }} />
                      <Typography variant="body2">Badminton</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <SportsEsportsIcon sx={{ mr: 1 }} />
                      <Typography variant="body2">Play Games</Typography>
                    </Box>
                  </Stack>
                </MotionCard>
              </Stack>
            </Grid>

            <Grid item xs={12} md={8}>
              <Stack spacing={4}>
                <MotionCard
                  variants={item}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  sx={{ borderRadius: '16px', overflow: 'hidden', p: 4 }}
                >
                  <Typography variant="h4" fontWeight={700} gutterBottom>
                    About Me
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Typography variant="body1" paragraph>
                    Front-End Developer with over 3 years of experience specializing in building modern, high-performance web applications using ReactJS, TypeScript, and Zustand. Skilled in translating UI/UX designs from Figma into responsive interfaces and optimizing load times by up to 35%. Adept at managing API integrations, collaborating in Agile teams, and delivering clean, maintainable code. Enthusiastic about creating user-centric digital products and always ready to explore new technologies.
                  </Typography>
                </MotionCard>

                <MotionCard
                  variants={item}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  sx={{ borderRadius: '16px', overflow: 'hidden', p: 4 }}
                >
                  <Typography variant="h4" fontWeight={700} gutterBottom>
                    Work Experience
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Stack spacing={3}>
                    <Box>
                      <Typography variant="h6" fontWeight={600}>
                        2024 - 2025 | Front-End Developer
                      </Typography>
                      <Typography variant="subtitle1" color="primary.main">
                        LiA Beauty Investment And Development Company Limited
                      </Typography>
                      <List dense>
                        <ListItem><ListItemText primary="Participate in building internal management dashboard using ReactJS + Material UI + Zustand + Support mobile programming with React Native" /></ListItem>
                        <ListItem><ListItemText primary="Optimize page loading performance to reduce load time by 35%" /></ListItem>
                        <ListItem><ListItemText primary="Connect and Manage APIs with React Query and Axios" /></ListItem>
                        <ListItem><ListItemText primary="Collaborate with UI/UX designers to convert Figma designs into reusable components" /></ListItem>
                        <ListItem><ListItemText primary="Manage source code with Github, use Merge Request Review regularly" /></ListItem>
                        <ListItem><ListItemText primary="Using AI tools to optimize work" /></ListItem>
                      </List>
                    </Box>
                    <Box>
                      <Typography variant="h6" fontWeight={600}>
                        2020 - 2023 | Web Developer
                      </Typography>
                      <Typography variant="subtitle1" color="primary.main">
                        Satife Company Limited
                      </Typography>
                      <List dense>
                        <ListItem><ListItemText primary="Participate in building internal management dashboard using ReactJS + Material UI + Redux" /></ListItem>
                        <ListItem><ListItemText primary="Build dashboards to manage rising and falling cash flows, add charts to identify" /></ListItem>
                        <ListItem><ListItemText primary="Optimize page loading performance to reduce load time by 35%" /></ListItem>
                        <ListItem><ListItemText primary="Connect and Manage APIs with Axios" /></ListItem>
                        <ListItem><ListItemText primary="Manage source code with GitLab, use Merge Request Review regularly" /></ListItem>
                      </List>
                    </Box>
                    <Box>
                      <Typography variant="h6" fontWeight={600}>
                        2019 - 2020 | System setup and operation (TTS)
                      </Typography>
                      <Typography variant="subtitle1" color="primary.main">
                        Hung Phat Ben Thanh Company Limited
                      </Typography>
                      <List dense>
                        <ListItem><ListItemText primary="As a member of the technology team, perform ad hoc tasks as requested by the IT Director. Based on a specific brief, ensure that websites are built in accordance" /></ListItem>
                        <ListItem><ListItemText primary="Help end users solve operational problems." /></ListItem>
                        <ListItem><ListItemText primary="Regularly handle other issues at the company's domestic and foreign branches." /></ListItem>
                        <ListItem><ListItemText primary="Write software documentation and specifications. Resolve cross-browser compatibility issues." /></ListItem>
                        <ListItem><ListItemText primary="Perform maintenance and updates for network lines and machines in the company." /></ListItem>
                      </List>
                    </Box>
                  </Stack>
                </MotionCard>

                <MotionCard
                  variants={item}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true }}
                  sx={{ borderRadius: '16px', overflow: 'hidden', p: 4 }}
                >
                  <Typography variant="h4" fontWeight={700} gutterBottom>
                    Personal Projects
                  </Typography>
                  <Divider sx={{ mb: 2 }} />
                  <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                    Websites built with html5, css3 (TailwindCSS)
                  </Typography>
                  <List dense>
                    <ListItem>
                      <ListItemIcon><WebIcon color="primary" /></ListItemIcon>
                      <ListItemText primary="LiA Vietnam" secondary="https://liavietnam.vn/" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><WebIcon color="primary" /></ListItemIcon>
                      <ListItemText primary="Trang Beauty Clinic" secondary="https://phongkhamtrangbeauty.com/" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><WebIcon color="primary" /></ListItemIcon>
                      <ListItemText primary="Hutancoffee" secondary="https://hutancoffee.com/" />
                    </ListItem>
                    <ListItem>
                      <ListItemIcon><WebIcon color="primary" /></ListItemIcon>
                      <ListItemText primary="Scrap" secondary="https://hiepphelieu.com/" />
                    </ListItem>
                  </List>
                </MotionCard>
              </Stack>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </PageAnimation>
  );
}; 