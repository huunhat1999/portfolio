export { HomePage } from './HomePage';
export { SkillsPage } from './SkillsPage';
export { PortfolioPage } from './PortfolioPage';
export { AboutPage } from './AboutPage';
export { ContactPage } from './ContactPage'; 