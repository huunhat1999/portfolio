export interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  technologies: string[];
  link?: string;
  github?: string;
  
  // Additional details for project modal
  role?: string;
  duration?: string;
  teamSize?: string;
  keyFeatures?: string[];
  challenges?: string[];
  solutions?: string[];
  longDescription?: string;
}

export interface Skill {
  name: string;
  icon: string;
  level: number;
}

export interface SocialLink {
  platform: string;
  url: string;
  icon: string;
} 