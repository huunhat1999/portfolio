declare module 'react-typical' {
  import React from 'react';
  
  interface TypicalProps {
    steps: (string | number)[];
    loop?: number;
    wrapper?: keyof JSX.IntrinsicElements | React.ComponentType<any>;
    className?: string;
  }
  
  const Typical: React.FC<TypicalProps>;
  
  export default Typical;
} 