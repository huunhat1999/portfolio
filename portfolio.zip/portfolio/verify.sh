#!/bin/bash

echo "Checking yarn version..."
yarn --version

echo "Initializing project..."
yarn install --check-files

echo "Verification complete. You can now run:"
echo "  yarn start    # to start the development server" 