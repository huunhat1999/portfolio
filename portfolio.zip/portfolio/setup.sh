#!/bin/bash

echo "🚀 Setting up portfolio project..."

# Remove package-lock.json to avoid conflict with yarn
echo "🧹 Cleaning up package-lock.json..."
if [ -f "package-lock.json" ]; then
  rm package-lock.json
fi

# Clean yarn cache
echo "🧹 Cleaning yarn cache..."
yarn cache clean

# Install dependencies
echo "📦 Installing dependencies..."
yarn install

# Create necessary directories if they don't exist
echo "📁 Setting up directory structure..."
mkdir -p public/icons public/projects

# Check for TypeScript errors
echo "🔍 Checking for TypeScript errors..."
yarn typecheck

# Start the application
echo "🚀 Starting the application..."
echo "The application will start in a moment. Press Ctrl+C to stop."
yarn start 